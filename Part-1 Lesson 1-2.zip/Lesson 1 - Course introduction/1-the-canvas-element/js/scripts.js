var canvas = document.getElementById('our-canvas'), // Our canvas element
    context = canvas.getContext('2d'); // 2d is the way to go here.

context.fillRect(25, 25, 25, 25);